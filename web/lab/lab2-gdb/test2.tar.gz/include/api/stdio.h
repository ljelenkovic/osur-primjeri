/*! Printing on stdout/stderr */
#pragma once

int printf ( char *fmt, ... );
void warn ( char *fmt, ... );

int stdio_init ();

/*! Printing on stdout (from kernel) */
#pragma once

#include <types/io.h>

int kprintf ( char *fmt, ... );

/*! Print on console using video memory */

#ifdef VGA_TEXT

#include "../io.h"
#include <types/io.h>
#include <lib/string.h>

#define VIDEO		0x000B8000 /* video memory address */
#define COLS		80 /* number of characters in a column */
#define ROWS		25 /* number of characters in a row */

/*! cursor position */
static int xp = 0;
static int yp = 0;

/*! starting address of video memory */
volatile static unsigned char *video = (void *) VIDEO;

/*! font color */
#define COLOR_WHITE	7
#define COLOR_RED	4
#define COLOR_GREEN	2
#define COLOR_DEFAULT	COLOR_WHITE

/*!
 * Supported escape sequences:
 * - "\x1b[2J"		=> clear screen
 * - "\x1b[x;yH"	=> move cursor to y,x (y=row, x=column)
 * - "\x1b[31m"		=> font color = COLOR_RED
 * - "\x1b[32m"		=> font color = COLOR_GREEN
 * - "\x1b[37m"		=> font color = COLOR_WHITE
 * - "\x1b[39m"		=> font color = COLOR_DEFAULT
 */

/*! current font color */
static int font_color = COLOR_DEFAULT;

static int color[3] = {
	7, /* 'normal' characters - white on black background */
	4, /* 'kernel' font - red */
	2  /* 'program' font - green */
};

#define PUT_CHAR(X,Y,CHAR)						\
do {									\
	video [ (X + (Y) * COLS) * 2 ] = (CHAR) & 0x00FF;		\
	video [ (X + (Y) * COLS) * 2 + 1 ] = font_color;		\
} while (0)


static int vga_text_clear ();
static int vga_text_gotoxy ( int x, int y );

/*! Init console */
static int vga_text_init ( int flags )
{
	static int init = FALSE;

	if ( init == TRUE )
		return 0;

	init = TRUE;
	video = (unsigned char *) VIDEO;
	xp = yp = 0;

	return vga_text_clear ();
}

/*! Clear console */
static int vga_text_clear ()
{
	int x;

	for ( x = 0; x < COLS * ROWS; x++ )
	{
		video [2*x] = 0;
		video [2*x+1] = color[2]; /* 'program' style */
	}

	return vga_text_gotoxy ( 0, 0 );
}

/*!
 * Move cursor to specified location
 * \param x Row where to put cursor
 * \param y Column where to put cursor
 */
static int vga_text_gotoxy ( int x, int y )
{
	unsigned short int t;

	xp = x;
	yp = y;
	t = yp * 80 + xp;

	outb ( 0x3D4, 14 );
	outb ( 0x3D5, t >> 8 );
	outb ( 0x3D4, 15 );
	outb ( 0x3D5, t & 0xFF );

	return 0;
}

/*! Parse escape sequence */
static int vga_process_escape_sequence ( char *text )
{
	int x = 0, n, m;

	if ( text[x] != '[' )
		return x; /* not supported (valid) escape sequence */

	x++;
	if ( text[x] >= '0' && text[x] <= '9' ) {
		n = text[x++] - '0';
		if ( text[x] >= '0' && text[x] <= '9' )
			n = n * 10 + text[x++] - '0';

		if ( text[x] == 'J' ) {
			if ( n == 2 )
				vga_text_clear ();
			//else => unsupported; ignore

			x++;
		}

		else if ( text[x] == 'm' ) {
			switch ( n ) {
			case ESC_COLOR_RED:
				font_color = COLOR_RED;
				break;
			case ESC_COLOR_GREEN:
				font_color = COLOR_GREEN;
				break;
			case ESC_COLOR_WHITE:
				font_color = COLOR_WHITE;
				break;
			case ESC_COLOR_DEFAULT:
				font_color = COLOR_DEFAULT;
				break;
			default: break;//ignore
			}

			x++;
		}

		else if ( text[x] == ';' ) {
			x++;
			if ( text[x] >= '0' && text[x] <= '9' ) {
				m = text[x++] - '0';
				if ( text[x] >= '0' && text[x] <= '9' )
					m = m * 10 + text[x++] - '0';

				if ( text[x] == 'H' || text[x] == 'f' ) {
					if ( m <= COLS && n <= ROWS )
						vga_text_gotoxy ( m-1, n-1 );
					//else => unsupported; ignore
					x++;
				}
				//else => unsupported; ignore
			}
			//else => unsupported; ignore
		}

		//else => unsupported; ignore
	}

	return x;
}

/*!
 * Print text string on console, starting at current cursor position
 * \param data String to print
 */
static int vga_text_printf ( char *text )
{
	int x, c, y=0;

	while ( text[y] )
	{
		if ( text[y] == ESCAPE ) {
			y++;
			y += vga_process_escape_sequence ( &text[y] );
			continue;
		}

		switch ( c = text[y++] )
		{
		case '\t': /* tabulator */
			xp = ( xp / 8 + 1 ) * 8;
			break;

		case '\r': /* carriage return */
			xp = 0;

		case '\n': /* new line */
			break;

		case '\b': /* backspace */
			if ( xp > 0 )
			{
				xp--;
				PUT_CHAR ( xp, yp, ' ' );
			}
			break;

		default: /* "regular" character */
			PUT_CHAR ( xp, yp, c );
			xp++;
		}

		if ( xp >= COLS || c == '\n' ) /* continue on new line */
		{
			xp = 0;
			if ( yp < ROWS - 1 )
			{
				yp++;
				for ( x = 0; x < COLS; x++ )
					(&c)[x] = 0;
			}
			else {
				/*scroll one line: move bottom ROWS-1 rows up*/
				for ( x = 0; x < COLS * 2 * (ROWS-1); x++ )
					video [x] = video [ x + COLS * 2 ];

				for ( x = 0; x < COLS; x++ )
					PUT_CHAR ( x, ROWS-2, ' ' );
			}
		}
	}

	vga_text_gotoxy ( xp, yp );

	return y;
}

/*! vga_text as console */
console_t vga_text = (console_t)
{
	.init	= vga_text_init,
	.print	= vga_text_printf
};

static int _do_nothing_ ()
{
	return 0;
}

/*! dev_null */
console_t dev_null = (console_t)
{
	.init	= (void *) _do_nothing_,
	.print	= (void *) _do_nothing_
};

#endif /* VGA_TEXT */

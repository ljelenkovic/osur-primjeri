#pragma once

#include <ARCH/processor.h>

#define halt()			arch_halt()

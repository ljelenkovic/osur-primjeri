#pragma once

int printf ( char *format, ... );
void warn ( char *format, ... );

int stdio_init ();

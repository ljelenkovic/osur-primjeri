#pragma once

#include <types/io.h>

int kprintf ( char *format, ... );

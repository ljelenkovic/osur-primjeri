/*! Program info */
#pragma once

#include <types/basic.h>

/* "programs" */
int hello ();
int debug ();

#define	hello_world_PROG_HELP	"Print 'Hello world'."
#define	debug_PROG_HELP		"Simple program prepared for little debugging."

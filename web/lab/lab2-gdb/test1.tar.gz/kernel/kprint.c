/*! Formated printing on console */
#define _K_PRINT_C_

#include <kernel/kprint.h> /* shares kprint with arch layer */

#include <lib/string.h>
#include <types/io.h>

console_t *kstdout; /* initialized in startup.c */

/*! Formated output to console (lightweight version of 'printf') */
int kprintf ( char *fmt, ... )
{
	size_t sz;
	char buf[5];//CONSOLE_MAXLEN];

	kstdout->print ( "\x1b[31m" ); /* red color for text */

	sz = vssprintf ( buf, CONSOLE_MAXLEN, &fmt );
	kstdout->print ( buf );

	kstdout->print ( "\x1b[39m" ); /* default color for text */

	return sz;
}
